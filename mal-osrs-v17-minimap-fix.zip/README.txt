V17 — MINIMAP FIX

Changes from V16:
- Circular aperture enlarged/repositioned to match the actual transparent
  opening in the 211x191 frame:
    transparent opening bbox = x 53..204, y 7..158
    clip center ~= 129,83; radius 76px
- OSRS world map is no longer forced down to 1320px.
  background-size is now auto auto, i.e. intrinsic/native image size.
- Scroll movement bug fixed:
  V16 set fallback background-position with !important, which overrode the
  keyframe animation. V17 removes that conflict.
- Uses animation-timeline: scroll(root block) with a 1ms duration.
- Default route now uses small pixel offsets suitable for native map zoom.
- Route can still be edited directly in MAL beneath the @import.

UPLOAD:
  /theme-v17.css
  /css/26-stats-minimap-v2.css

MAL:
  use MAL_IMPORT_V17.txt, or at minimum:
  @\import "https://cdn.jsdelivr.net/gh/Tafixados/mal-osrs@main/theme-v17.css";

BROWSER NOTE:
Scroll-driven CSS animation support depends on browser support. Chromium
browsers support it. If testing in Firefox and the map remains static even
after this fix, test the same page in Chrome/Edge before changing the route.
